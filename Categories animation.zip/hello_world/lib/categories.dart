import 'package:flutter/material.dart';

class CategoryCard {
  Color color;
  String title;
  double height;
  String image;

  CategoryCard({this.color, this.title, this.height, this.image});
}

class CategoriesPage extends StatefulWidget {
  @override
  _CategoriesPageState createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  int _currentIndex = 0;
  ScrollController _scrollController;

  List<CategoryCard> categories = [
    CategoryCard(
        color: Colors.red,
        title: "Category 1",
        height: 300,
        image: "images/card1.jpeg"),
    CategoryCard(
        color: Colors.black,
        title: "Category 2",
        height: 150,
        image: "images/card2.jpeg"),
    CategoryCard(
        color: Colors.green,
        title: "Category 3",
        height: 150,
        image: "images/card3.jpeg"),
    CategoryCard(
        color: Colors.yellow,
        title: "Category 4",
        height: 150,
        image: "images/card4.jpeg"),
    CategoryCard(
        color: Colors.pink,
        title: "Category 5",
        height: 150,
        image: "images/card7.jpeg"),
    CategoryCard(
        color: Colors.brown,
        title: "Category 6",
        height: 150,
        image: "images/card6.jpeg"),
    CategoryCard(
        color: Colors.orange,
        title: "Category 7",
        height: 150,
        image: "images/card5.jpeg"),
  ];

  @override
  void initState() {
    _scrollController = new ScrollController();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Categories animation"),
      ),
      body: ListView.builder(
        itemCount: categories.length,
        physics: NeverScrollableScrollPhysics(),
        controller: _scrollController,
        itemBuilder: (context, index) {
          return GestureDetector(
            onVerticalDragEnd: (details) {
              setState(() {
                categories[_currentIndex].height = 150;
              });
              if (details.velocity.pixelsPerSecond.dy >= 0) {
                if (_currentIndex > 0) _currentIndex--;
              } else {
                if (_currentIndex < 6) _currentIndex++;
              }
              setState(() {
                categories[_currentIndex].height = 300;
                _scrollController.animateTo((_currentIndex) * 166.0,
                    duration: Duration(milliseconds: 500),
                    curve: Curves.linear);
              });
            },
            child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: CategoryCardAnimated(categories[index])),
          );
        },
      ),
    );
  }
}

class CategoryCardAnimated extends StatefulWidget {
  final CategoryCard categoryCard;

  CategoryCardAnimated(this.categoryCard);

  @override
  _CategoryCardAnimatedState createState() => _CategoryCardAnimatedState();
}

class _CategoryCardAnimatedState extends State<CategoryCardAnimated> {
  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      curve: Curves.linear,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(widget.categoryCard.image),
            fit: BoxFit.cover),
        color: widget.categoryCard.color,
        borderRadius: BorderRadius.circular(10),
      ),
      height: widget.categoryCard.height,
      duration: Duration(milliseconds: 500),
      child: Text(widget.categoryCard.title,
          style: TextStyle(color: Colors.white, fontSize: 30)),
    );
  }
}